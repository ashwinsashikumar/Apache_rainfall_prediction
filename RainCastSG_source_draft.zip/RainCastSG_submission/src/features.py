# Extracted from RainCastSG.ipynb; requires Spark session and BASE initialized.

# Notebook cell 45

from pyspark.sql import functions as F
from pyspark.sql.window import Window

spark.conf.set("spark.sql.session.timeZone", "Asia/Singapore")
spark.conf.set("spark.sql.shuffle.partitions", "16")

# Load all years
raw_all = spark.read.parquet(*[
    str(BASE / "processed" / f"rainfall_{y}")
    for y in range(2017, 2025)
])

# Normalize to 5-minute buckets
bucketed = raw_all.select(
    "station_id",
    "rainfall_mm",
    F.timestamp_seconds(
        F.floor(F.unix_timestamp("timestamp_sgt") / 300) * 300
    ).alias("time_bucket")
)

# Resolve any duplicate buckets deterministically
bucketed = bucketed.groupBy(
    "station_id", "time_bucket"
).agg(F.avg("rainfall_mm").alias("rainfall_mm"))

w = Window.partitionBy("station_id").orderBy("time_bucket")

# Historical rolling windows, including current observation
features_all = (bucketed
    .withColumn("rain_5m", F.col("rainfall_mm"))
    .withColumn("rain_15m", F.sum("rainfall_mm").over(w.rowsBetween(-2, 0)))
    .withColumn("rain_30m", F.sum("rainfall_mm").over(w.rowsBetween(-5, 0)))
    .withColumn("rain_60m", F.sum("rainfall_mm").over(w.rowsBetween(-11, 0)))
    .withColumn("future_30m", F.sum("rainfall_mm").over(w.rowsBetween(1, 6)))
    .withColumn("past_time", F.lag("time_bucket", 11).over(w))
    .withColumn("future_time", F.lead("time_bucket", 6).over(w))
)

# Retain only complete consecutive windows
features_all = features_all.filter(
    (F.unix_timestamp("time_bucket") -
     F.unix_timestamp("past_time") == 3300) &
    (F.unix_timestamp("future_time") -
     F.unix_timestamp("time_bucket") == 1800)
)

features_all = features_all.select(
    "station_id",
    "time_bucket",
    F.year("time_bucket").alias("year"),
    F.month("time_bucket").alias("month"),
    F.hour("time_bucket").alias("hour"),
    "rain_5m", "rain_15m", "rain_30m",
    "rain_60m", "future_30m"
)

print("Feature pipeline defined successfully!")
features_all.printSchema()


# Notebook cell 46

output = str(BASE / "processed" / "features_all")

(features_all.write
    .mode("overwrite")
    .option("compression", "snappy")
    .parquet(output))

print("All-year features saved!")


# Notebook cell 47

all_features = spark.read.parquet(output)

all_features.groupBy("year").count().orderBy("year").show()

