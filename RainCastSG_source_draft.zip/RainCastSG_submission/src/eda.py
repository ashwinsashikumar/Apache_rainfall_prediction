# Extracted from RainCastSG.ipynb; requires Spark session and BASE initialized.

# Notebook cell 18

from pyspark.sql import functions as F

spark.conf.set("spark.sql.session.timeZone", "Asia/Singapore")
spark.conf.set("spark.sql.shuffle.partitions", "8")

paths = [
    str(BASE / "processed" / f"rainfall_{year}")
    for year in range(2017, 2025)
]

rainfall = spark.read.parquet(*paths)

rainfall = rainfall.withColumn(
    "year", F.year("timestamp_sgt")
).withColumn(
    "month", F.month("timestamp_sgt")
).withColumn(
    "hour", F.hour("timestamp_sgt")
)

rainfall.createOrReplaceTempView("rainfall")

print("Rainfall dataset registered as a Spark SQL table!")
rainfall.printSchema()


# Notebook cell 19

annual_stats = spark.sql("""
WITH station_year AS (
    SELECT
        year,
        station_id,
        COUNT(*) AS observations,
        SUM(rainfall_mm) AS annual_total_mm,
        AVG(rainfall_mm) AS mean_5min_mm,
        SUM(CASE WHEN rainfall_mm > 0 THEN 1 ELSE 0 END) AS wet_intervals
    FROM rainfall
    GROUP BY year, station_id
)
SELECT
    year,
    COUNT(*) AS stations,
    ROUND(AVG(annual_total_mm), 2) AS avg_station_annual_mm,
    ROUND(AVG(mean_5min_mm), 4) AS avg_5min_mm,
    ROUND(SUM(wet_intervals) * 100.0 / SUM(observations), 2) AS wet_interval_pct
FROM station_year
GROUP BY year
ORDER BY year
""")

annual_stats.show(10, truncate=False)


# Notebook cell 20

import matplotlib.pyplot as plt

annual_pd = annual_stats.toPandas()

plt.figure(figsize=(10, 5))
plt.bar(
    annual_pd["year"].astype(str),
    annual_pd["avg_station_annual_mm"]
)

plt.xlabel("Year")
plt.ylabel("Mean observed annual rainfall per station (mm)")
plt.title("Singapore Rainfall Patterns (2017–2024)")
plt.grid(axis="y", alpha=0.25)
plt.tight_layout()

figure_path = BASE / "figures" / "annual_rainfall.png"
plt.savefig(figure_path, dpi=300, bbox_inches="tight")
plt.show()

print("Figure saved:", figure_path)


# Notebook cell 21

monthly_stats = spark.sql("""
WITH station_month AS (
    SELECT
        year, month, station_id,
        SUM(rainfall_mm) AS total_mm,
        COUNT(*) AS observations
    FROM rainfall
    GROUP BY year, month, station_id
)
SELECT
    year, month,
    COUNT(*) AS stations,
    ROUND(AVG(total_mm), 2) AS avg_station_monthly_mm,
    ROUND(SUM(total_mm) * 288.0 / SUM(observations), 2)
        AS coverage_normalized_daily_mm
FROM station_month
GROUP BY year, month
ORDER BY year, month
""")

monthly_stats.show(15, truncate=False)


# Notebook cell 22

import pandas as pd
import matplotlib.pyplot as plt

monthly_pd = monthly_stats.toPandas()

seasonal = monthly_pd.groupby("month")[
    "coverage_normalized_daily_mm"
].mean()

month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

plt.figure(figsize=(10, 5))
plt.plot(month_names, seasonal.values, marker="o", linewidth=2)
plt.xlabel("Month")
plt.ylabel("Coverage-normalized daily rainfall (mm)")
plt.title("Average Monthly Rainfall Seasonality in Singapore (2017–2024)")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(BASE / "figures" / "monthly_seasonality.png", dpi=300)
plt.show()


# Notebook cell 23

import numpy as np

heatmap_data = monthly_pd.pivot(
    index="year",
    columns="month",
    values="coverage_normalized_daily_mm"
).sort_index()

fig, ax = plt.subplots(figsize=(12, 5))
im = ax.imshow(heatmap_data.values, aspect="auto", cmap="YlGnBu")

ax.set_xticks(range(12))
ax.set_xticklabels(month_names)
ax.set_yticks(range(len(heatmap_data.index)))
ax.set_yticklabels(heatmap_data.index)

for i in range(len(heatmap_data.index)):
    for j in range(12):
        value = heatmap_data.iloc[i, j]
        if pd.notna(value):
            ax.text(j, i, f"{value:.1f}", ha="center",
                    va="center", fontsize=8)

plt.colorbar(im, ax=ax, label="Estimated daily rainfall (mm)")
plt.title("Monthly Rainfall Patterns Across Years (2017–2024)")
plt.tight_layout()
plt.savefig(BASE / "figures" / "rainfall_heatmap.png", dpi=300)
plt.show()


# Notebook cell 24

hourly_stats = spark.sql("""
SELECT
    hour,
    COUNT(*) AS observations,
    ROUND(AVG(rainfall_mm), 5) AS mean_5min_rainfall,
    ROUND(
        100.0 * SUM(CASE WHEN rainfall_mm > 0 THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS wet_interval_pct
FROM rainfall
GROUP BY hour
ORDER BY hour
""")

hourly_stats.show(24, truncate=False)


# Notebook cell 25

hourly_pd = hourly_stats.toPandas()

plt.figure(figsize=(10, 5))
plt.plot(hourly_pd["hour"], hourly_pd["wet_interval_pct"],
         marker="o", linewidth=2)
plt.xticks(range(0, 24, 2))
plt.xlabel("Hour of Day (Singapore Time)")
plt.ylabel("Wet Observations (%)")
plt.title("Hourly Rainfall Occurrence in Singapore (2017–2024)")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(BASE / "figures" / "hourly_rainfall.png", dpi=300)
plt.show()


# Notebook cell 26

intensity_stats = spark.sql("""
SELECT
    CASE
        WHEN rainfall_mm = 0 THEN '0: No rain'
        WHEN rainfall_mm <= 0.5 THEN '1: 0–0.5 mm'
        WHEN rainfall_mm <= 2 THEN '2: 0.5–2 mm'
        WHEN rainfall_mm <= 5 THEN '3: 2–5 mm'
        WHEN rainfall_mm <= 10 THEN '4: 5–10 mm'
        ELSE '5: >10 mm'
    END AS intensity_category,
    COUNT(*) AS observations
FROM rainfall
GROUP BY 1
ORDER BY 1
""")

intensity_stats.show(truncate=False)


# Notebook cell 27

intensity_pd = intensity_stats.toPandas()
wet_pd = intensity_pd[
    intensity_pd["intensity_category"] != "0: No rain"
].copy()

wet_pd["percentage"] = (
    wet_pd["observations"] / wet_pd["observations"].sum() * 100
)

plt.figure(figsize=(10, 5))
plt.bar(wet_pd["intensity_category"], wet_pd["percentage"])
plt.xlabel("Rainfall per 5-minute interval")
plt.ylabel("Percentage of wet observations (%)")
plt.title("Distribution of Non-Zero Rainfall Intensity (2017–2024)")
plt.xticks(rotation=20)
plt.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(BASE / "figures" / "rainfall_intensity.png", dpi=300)
plt.show()


# Notebook cell 28

station_stats = spark.sql("""
SELECT
    station_id,
    MAX(station_name) AS station_name,
    ROUND(AVG(latitude), 5) AS latitude,
    ROUND(AVG(longitude), 5) AS longitude,
    COUNT(*) AS observations,
    ROUND(AVG(rainfall_mm) * 288, 2) AS estimated_daily_mm,
    ROUND(100.0 * AVG(CASE WHEN rainfall_mm > 0 THEN 1.0 ELSE 0.0 END), 2)
        AS wet_interval_pct
FROM rainfall
GROUP BY station_id
HAVING COUNT(*) >= 10000
ORDER BY estimated_daily_mm DESC
""")

station_stats.show(15, truncate=False)


# Notebook cell 29

station_pd = station_stats.toPandas()

plt.figure(figsize=(11, 7))

scatter = plt.scatter(
    station_pd["longitude"],
    station_pd["latitude"],
    c=station_pd["estimated_daily_mm"],
    s=75,
    cmap="YlGnBu",
    edgecolors="black",
    linewidths=0.4
)

plt.colorbar(scatter, label="Estimated daily rainfall (mm)")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.title("Spatial Variation in Rainfall Across Singapore (2017–2024)")
plt.grid(alpha=0.2)
plt.tight_layout()

plt.savefig(BASE / "figures" / "spatial_rainfall.png", dpi=300)
plt.show()


# Notebook cell 31

import geopandas as gpd
import matplotlib.pyplot as plt
import requests

# Download Singapore's geographical boundary
url = "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson"
response = requests.get(url, timeout=60)
response.raise_for_status()

geojson_path = "/content/countries.geojson"
with open(geojson_path, "wb") as f:
    f.write(response.content)

# Load the boundary
countries = gpd.read_file(geojson_path)
print("Available columns:", countries.columns.tolist())

name_col = "ADMIN" if "ADMIN" in countries.columns else "name"
singapore = countries[
    countries[name_col].str.lower() == "singapore"
]

print("Singapore polygons:", len(singapore))


# Notebook cell 32

from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

fig, ax = plt.subplots(figsize=(12, 7))

# Singapore boundary
singapore.plot(
    ax=ax,
    color="#F1F5F9",
    edgecolor="#64748B",
    linewidth=1.2
)

# Actual rainfall station coordinates
scatter = ax.scatter(
    station_pd["longitude"],
    station_pd["latitude"],
    c=station_pd["estimated_daily_mm"],
    cmap="YlGnBu",
    s=75,
    edgecolors="black",
    linewidths=0.4,
    zorder=3
)

plt.colorbar(
    scatter,
    ax=ax,
    label="Estimated daily rainfall (mm)",
    shrink=0.75
)

ax.set_xlim(103.60, 104.05)
ax.set_ylim(1.20, 1.48)
ax.set_xlabel("Longitude")
ax.set_ylabel("Latitude")
ax.set_title(
    "Spatial Variation in Rainfall Across Singapore (2017–2024)"
)
ax.grid(alpha=0.15)
ax.set_aspect("equal", adjustable="box")

plt.tight_layout()
plt.savefig(
    BASE / "figures" / "spatial_rainfall_map.png",
    dpi=300,
    bbox_inches="tight"
)
plt.show()

