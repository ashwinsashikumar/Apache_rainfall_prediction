"""Historical RainCastSG inference: python src/predict.py --base PATH --station S06 --time '2024-11-07 16:45:00' --threshold 3.5"""
import argparse
import math
from pathlib import Path
from pyspark.sql import SparkSession, functions as F
from pyspark.ml import PipelineModel
from pyspark.ml.classification import LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.functions import vector_to_array

KNOTS = (0., 1., 2., 5., 10.)

def predict(spark, base, station, time_sgt, threshold):
    if not 0 <= threshold <= 10:
        raise ValueError('Threshold must be between 0 and 10 mm')
    base = Path(base)
    df = spark.read.parquet(str(base / 'processed/features_all'))
    # Input string is interpreted in the Spark session timezone (SGT).
    rows = (df.filter((F.col('station_id') == station) &
                      (F.col('time_bucket') == F.to_timestamp(F.lit(time_sgt))))
              .select('station_id','time_bucket','hour','month','rain_5m','rain_15m','rain_30m','rain_60m')
              .limit(1).collect())
    if not rows:
        raise ValueError('Station/time not found or insufficient history')
    x = spark.createDataFrame(rows)
    x = (x.withColumn('hour_sin',F.sin(2*math.pi*F.col('hour')/24))
          .withColumn('hour_cos',F.cos(2*math.pi*F.col('hour')/24))
          .withColumn('month_sin',F.sin(2*math.pi*F.col('month')/12))
          .withColumn('month_cos',F.cos(2*math.pi*F.col('month')/12)))
    model = PipelineModel.load(str(base/'models/raincast_final_lr'))
    assembler = VectorAssembler(inputCols=['logit_raw'],outputCol='cal_features')
    needed = [t for t in KNOTS if t == threshold]
    if not needed:
        needed = [max(t for t in KNOTS if t < threshold),min(t for t in KNOTS if t > threshold)]
    probabilities = {}
    for t in needed:
        scored = model.transform(x.withColumn('threshold_mm',F.lit(t)))
        scored = scored.withColumn('p_raw',vector_to_array('probability')[1]).drop('prediction','probability','rawPrediction')
        p = F.greatest(F.lit(1e-6),F.least(F.col('p_raw'),F.lit(1-1e-6)))
        scored = assembler.transform(scored.withColumn('logit_raw',F.log(p/(1-p))))
        calibrator = LogisticRegressionModel.load(str(base/f'models/calibrator_{int(t)}mm'))
        probabilities[t] = float(calibrator.transform(scored).select(vector_to_array('probability')[1].alias('p')).first()['p'])
    if len(needed) == 1:
        probability = probabilities[needed[0]]
    else:
        lo,hi = needed
        probability = probabilities[lo] + (threshold-lo)/(hi-lo)*(probabilities[hi]-probabilities[lo])
    return {'station_id':station,'prediction_time_sgt':time_sgt,'threshold_mm':threshold,'probability':probability}

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--base',required=True)
    parser.add_argument('--station',required=True)
    parser.add_argument('--time',required=True)
    parser.add_argument('--threshold',type=float,required=True)
    args=parser.parse_args()
    spark=(SparkSession.builder.appName('RainCastSGInference').master('local[2]').config('spark.sql.session.timeZone','Asia/Singapore').getOrCreate())
    try:
        print(predict(spark,args.base,args.station,args.time,args.threshold))
    finally:
        spark.stop()
