# Extracted from RainCastSG.ipynb; requires Spark session and BASE initialized.

# Notebook cell 13

import requests, time, gc
from pathlib import Path
from pyspark.sql import functions as F
from pyspark.sql.window import Window

spark.conf.set("spark.sql.session.timeZone", "Asia/Singapore")
API = "https://api-open.data.gov.sg/v1/public/api"
RAW = Path("/content/rainfall_raw")
RAW.mkdir(parents=True, exist_ok=True)

def process_year(year):
    dataset_id = rainfall_datasets[year]
    output = str(BASE / "processed" / f"rainfall_{year}")
    csv_path = RAW / f"rainfall_{year}.csv"

    # Skip years that have already been processed.
    if (Path(output) / "_SUCCESS").exists():
        print(f"{year}: Already processed. Skipping.")
        return

    print(f"\n========== Processing {year} ==========", flush=True)

    # 1. Request a fresh signed download URL.
    init = requests.get(
        f"{API}/datasets/{dataset_id}/initiate-download",
        timeout=90
    )
    init.raise_for_status()
    payload = init.json()
    if payload.get("code") != 0:
        raise RuntimeError(f"Download initiation failed: {payload}")

    download_url = payload["data"].get("url")
    if not download_url:
        raise RuntimeError(f"No download URL returned for {year}")

    # 2. Download in chunks without loading the CSV into RAM.
    if not csv_path.exists():
        with requests.get(download_url, stream=True, timeout=(30, 180)) as r:
            r.raise_for_status()
            with open(csv_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=4 * 1024 * 1024):
                    if chunk:
                        f.write(chunk)

    print(f"Downloaded: {csv_path.stat().st_size / 1024**2:.1f} MB", flush=True)

    # 3. Read the CSV using Spark.
    raw = spark.read.option("header", True).csv(str(csv_path))

    # 4. Standardize types and select useful columns.
    typed = raw.select(
        F.to_timestamp("timestamp").alias("timestamp_sgt"),
        F.trim("station_id").alias("station_id"),
        F.col("station_name"),
        F.col("reading_value").cast("double").alias("rainfall_mm"),
        F.col("location_latitude").cast("double").alias("latitude"),
        F.col("location_longitude").cast("double").alias("longitude"),
        F.to_timestamp("reading_update_timestamp").alias("reading_updated_at"),
        F.col("reading_unit")
    )

    # 5. Remove invalid observations.
    valid = typed.filter(
        F.col("timestamp_sgt").isNotNull() &
        F.col("station_id").isNotNull() &
        (F.col("station_id") != "") &
        F.col("rainfall_mm").isNotNull() &
        (F.col("rainfall_mm") >= 0) &
        (F.col("reading_unit") == "mm") &
        (F.year("timestamp_sgt") == year)
    )

    # 6. Resolve duplicates by retaining the latest updated reading.
    window = Window.partitionBy(
        "station_id", "timestamp_sgt"
    ).orderBy(
        F.col("reading_updated_at").desc_nulls_last(),
        F.col("rainfall_mm").desc(),
        F.col("station_name").asc_nulls_last()
    )

    clean = (valid
        .withColumn("_rank", F.row_number().over(window))
        .filter(F.col("_rank") == 1)
        .drop("_rank", "reading_updated_at", "reading_unit")
    )

    # 7. Write compressed Parquet to persistent Google Drive.
    (clean.write
        .mode("overwrite")
        .option("compression", "snappy")
        .parquet(output))

    # 8. Verify the saved data.
    saved = spark.read.parquet(output)
    stats = saved.agg(
        F.count("*").alias("rows"),
        F.countDistinct("station_id").alias("stations"),
        F.min("timestamp_sgt").alias("start"),
        F.max("timestamp_sgt").alias("end"),
        F.sum(F.when(F.col("rainfall_mm") > 0, 1).otherwise(0)).alias("wet_rows")
    ).first()

    print(f"{year}: {stats['rows']:,} rows, {stats['stations']} stations", flush=True)
    print(f"Coverage: {stats['start']} to {stats['end']}", flush=True)
    print(f"Wet observations: {stats['wet_rows']:,}", flush=True)

    # 9. Remove temporary CSV only after successful verification.
    csv_path.unlink()
    del raw, typed, valid, clean, saved
    gc.collect()

    print(f"{year}: COMPLETE!", flush=True)

