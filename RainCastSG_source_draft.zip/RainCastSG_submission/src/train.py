# Extracted from RainCastSG.ipynb; requires Spark session and BASE initialized.

# Notebook cell 48

from pyspark.sql import functions as F

all_features = spark.read.parquet(
    str(BASE / "processed" / "features_all")
)

# Exclude boundary observations whose targets cross into the next split.
train_base = all_features.filter(
    F.col("time_bucket") < "2022-12-31 23:30:00"
)

val_base = all_features.filter(
    (F.col("time_bucket") >= "2023-01-01 00:00:00") &
    (F.col("time_bucket") < "2023-12-31 23:30:00")
)

test_base = all_features.filter(
    F.col("time_bucket") >= "2024-01-01 00:00:00"
)

# Sample training data to keep Colab manageable.
train_base = train_base.sample(False, 0.05, seed=42)
val_base = val_base.sample(False, 0.10, seed=42)
test_base = test_base.sample(False, 0.10, seed=42)

print("Training rows:", train_base.count())
print("Validation rows:", val_base.count())
print("Testing rows:", test_base.count())


# Notebook cell 49

thresholds = F.array(
    F.lit(0.0), F.lit(1.0), F.lit(2.0),
    F.lit(5.0), F.lit(10.0)
)

def create_labels(df):
    return (df
        .withColumn("threshold_mm", F.explode(thresholds))
        .withColumn(
            "label",
            (F.col("future_30m") > F.col("threshold_mm")).cast("double")
        )
    )

train_final = create_labels(train_base)
val_final = create_labels(val_base)
test_final = create_labels(test_base)

print("Threshold-dependent labels created!")


# Notebook cell 50

import math

def add_time_features(df):
    return (df
        .withColumn("hour_sin", F.sin(2 * math.pi * F.col("hour") / 24))
        .withColumn("hour_cos", F.cos(2 * math.pi * F.col("hour") / 24))
        .withColumn("month_sin", F.sin(2 * math.pi * F.col("month") / 12))
        .withColumn("month_cos", F.cos(2 * math.pi * F.col("month") / 12))
    )

train_final = add_time_features(train_final)
val_final = add_time_features(val_final)
test_final = add_time_features(test_final)

print("Cyclical features added!")


# Notebook cell 51

from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, OneHotEncoder, VectorAssembler
from pyspark.ml.classification import LogisticRegression

indexer = StringIndexer(
    inputCol="station_id",
    outputCol="station_index",
    handleInvalid="keep"
)

encoder = OneHotEncoder(
    inputCols=["station_index"],
    outputCols=["station_vector"]
)

assembler = VectorAssembler(
    inputCols=[
        "station_vector",
        "hour_sin", "hour_cos",
        "month_sin", "month_cos",
        "rain_5m", "rain_15m",
        "rain_30m", "rain_60m",
        "threshold_mm"
    ],
    outputCol="features"
)

lr = LogisticRegression(
    featuresCol="features",
    labelCol="label",
    maxIter=30,
    regParam=0.05
)

final_pipeline = Pipeline(stages=[
    indexer, encoder, assembler, lr
])


# Notebook cell 52

final_model = final_pipeline.fit(train_final)

model_path = str(BASE / "models" / "raincast_final_lr")
final_model.write().overwrite().save(model_path)

print("Final historical model trained and saved!")
print("Model location:", model_path)

