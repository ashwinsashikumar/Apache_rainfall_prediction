# Extracted from RainCastSG.ipynb; requires Spark session and BASE initialized.

# Notebook cell 53

from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.sql import functions as F

evaluator = BinaryClassificationEvaluator(
    labelCol="label",
    rawPredictionCol="rawPrediction"
)

val_predictions = final_model.transform(val_final)

val_roc = evaluator.evaluate(
    val_predictions,
    {evaluator.metricName: "areaUnderROC"}
)

val_pr = evaluator.evaluate(
    val_predictions,
    {evaluator.metricName: "areaUnderPR"}
)

print(f"2023 Validation ROC-AUC: {val_roc:.4f}")
print(f"2023 Validation PR-AUC: {val_pr:.4f}")


# Notebook cell 54

test_predictions = final_model.transform(test_final)

test_roc = evaluator.evaluate(
    test_predictions,
    {evaluator.metricName: "areaUnderROC"}
)

test_pr = evaluator.evaluate(
    test_predictions,
    {evaluator.metricName: "areaUnderPR"}
)

print(f"2024 Test ROC-AUC: {test_roc:.4f}")
print(f"2024 Test PR-AUC: {test_pr:.4f}")


# Notebook cell 56

from pyspark.sql import functions as F
from pyspark.ml.functions import vector_to_array

calibration_df = (
    test_predictions
    .withColumn("p_rain", vector_to_array("probability")[1])
    .select("threshold_mm", "label", "p_rain")
)

calibration_stats = (
    calibration_df
    .groupBy("threshold_mm")
    .agg(
        F.count("*").alias("n"),
        F.round(F.avg("label"), 5).alias("actual_rate"),
        F.round(F.avg("p_rain"), 5).alias("mean_predicted_probability"),
        F.round(
            F.avg(F.pow(F.col("p_rain") - F.col("label"), 2)),
            5
        ).alias("brier_score")
    )
    .orderBy("threshold_mm")
)

calibration_stats.show(truncate=False)

calibration_stats.toPandas().to_csv(
    BASE / "results" / "calibration_summary.csv",
    index=False
)


# Notebook cell 57

from pyspark.sql import functions as F
from pyspark.ml.functions import vector_to_array

val_cal = (
    final_model.transform(val_final)
    .withColumn("p_raw", vector_to_array("probability")[1])
    .select("threshold_mm", "label", "p_raw")
)

test_cal = (
    final_model.transform(test_final)
    .withColumn("p_raw", vector_to_array("probability")[1])
    .select("threshold_mm", "label", "p_raw")
)

print("Validation and test predictions prepared!")


# Notebook cell 58

from pyspark.ml.classification import LogisticRegression
from pyspark.ml.feature import VectorAssembler

def add_logit(df):
    p = F.greatest(F.lit(1e-6),
                   F.least(F.col("p_raw"), F.lit(1 - 1e-6)))
    return df.withColumn(
        "logit_raw", F.log(p / (1 - p))
    )

assembler = VectorAssembler(
    inputCols=["logit_raw"],
    outputCol="cal_features"
)

cal_models = {}

for threshold in [0.0, 1.0, 2.0, 5.0, 10.0]:
    subset = val_cal.filter(F.col("threshold_mm") == threshold)
    prepared = assembler.transform(add_logit(subset))

    calibrator = LogisticRegression(
        featuresCol="cal_features",
        labelCol="label",
        maxIter=30,
        regParam=0.001
    )

    cal_models[threshold] = calibrator.fit(prepared)
    print(f"Calibrator trained for {threshold} mm")


# Notebook cell 59

from pyspark.ml.functions import vector_to_array

calibrated_parts = []

for threshold, cal_model in cal_models.items():
    subset = test_cal.filter(F.col("threshold_mm") == threshold)
    prepared = assembler.transform(add_logit(subset))

    calibrated = (
        cal_model.transform(prepared)
        .withColumn(
            "p_calibrated",
            vector_to_array("probability")[1]
        )
        .select("threshold_mm", "label", "p_raw", "p_calibrated")
    )

    calibrated_parts.append(calibrated)

calibrated_test = calibrated_parts[0]

for part in calibrated_parts[1:]:
    calibrated_test = calibrated_test.unionByName(part)

calibration_comparison = (
    calibrated_test.groupBy("threshold_mm")
    .agg(
        F.avg("label").alias("actual_rate"),
        F.avg("p_raw").alias("raw_mean"),
        F.avg("p_calibrated").alias("calibrated_mean"),
        F.avg(F.pow(F.col("p_raw") - F.col("label"), 2)).alias("raw_brier"),
        F.avg(F.pow(F.col("p_calibrated") - F.col("label"), 2)).alias("calibrated_brier")
    )
    .orderBy("threshold_mm")
)

calibration_comparison.show(truncate=False)


# Notebook cell 69

from pyspark.sql import functions as F
from pyspark.ml.functions import vector_to_array

# Calculate baseline probabilities from training data only
baseline_rates = (
    train_final.groupBy("threshold_mm")
    .agg(F.avg("label").alias("baseline_probability"))
)

# Compare on the same 2024 observations
baseline_test = (
    test_cal.join(baseline_rates, "threshold_mm")
    .withColumn(
        "baseline_brier_error",
        F.pow(F.col("baseline_probability") - F.col("label"), 2)
    )
)

baseline_results = (
    baseline_test.groupBy("threshold_mm")
    .agg(
        F.avg("label").alias("actual_rate"),
        F.avg("baseline_probability").alias("baseline_probability"),
        F.avg("baseline_brier_error").alias("baseline_brier")
    )
    .orderBy("threshold_mm")
)

baseline_results.show(truncate=False)

baseline_results.toPandas().to_csv(
    BASE / "results" / "baseline_comparison.csv",
    index=False
)


# Notebook cell 70

import pandas as pd
import matplotlib.pyplot as plt

baseline_pd = baseline_results.toPandas()
calibrated_pd = calibration_comparison.toPandas()

comparison = baseline_pd.merge(
    calibrated_pd[["threshold_mm", "calibrated_brier"]],
    on="threshold_mm"
)

ax = comparison.plot(
    x="threshold_mm",
    y=["baseline_brier", "calibrated_brier"],
    kind="bar",
    figsize=(10, 5),
    width=0.75
)

ax.set_xlabel("Rainfall threshold (mm)")
ax.set_ylabel("Brier score (lower is better)")
ax.set_title("Baseline vs Calibrated MLlib Model — 2024 Test Set")
ax.set_xticklabels(["0", "1", "2", "5", "10"], rotation=0)
ax.legend(["Historical baseline", "Calibrated MLlib"])
ax.grid(axis="y", alpha=0.25)

plt.tight_layout()
plt.savefig(
    BASE / "figures" / "baseline_vs_model.png",
    dpi=300,
    bbox_inches="tight"
)
plt.show()

comparison.to_csv(
    BASE / "results" / "final_model_comparison.csv",
    index=False
)

