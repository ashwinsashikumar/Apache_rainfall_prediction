# RainCastSG — Singapore Rainfall Analysis and Prediction

## Contents
- `notebooks/RainCastSG.ipynb`: original executed Colab development notebook.
- `src/predict.py`: standalone historical prediction entrypoint.
- `src/ingest.py`, `eda.py`, `features.py`, `train.py`, `evaluate.py`: **reference extracts** of notebook cells. These extracts are not standalone scripts; they require the notebook's session variables and should not be described as independently tested.

## Required external artifacts (not included in this source-only archive)
Copy the original Google Drive `RainCastSG/models/` and `RainCastSG/processed/features_all/` directories into the project root. Spark MLlib models are directories, not single files. The notebook's figures and results are also stored in Google Drive.

## Environment
Python 3.13, PySpark 4.0.4, Spark local[2], timezone Asia/Singapore. Use compatible Java and Python installations. Install `pyspark==4.0.4`, `pandas`, `matplotlib`; optional for the boundary map: `geopandas`, `requests`.

## Historical inference
From the project root:

```bash
python src/predict.py --base . --station S06 --time '2024-11-07 16:45:00' --threshold 3.5
```

Inputs are station ID, Singapore-local timestamp, and threshold in [0,10] mm. Inference requires historical features already present at the requested station-time. The prediction does **not** provide live future forecasts. Thresholds 0,1,2,5,10 use individual 2023-fitted calibrators; intermediate thresholds use linear interpolation.

## Research methodology
Source: NEA Historical Rainfall across Singapore, annual datasets 2017–2024 via data.gov.sg. Raw observations were cleaned and saved as Parquet. Features include station ID, cyclical hour/month and rainfall sums for previous 5, 15, 30 and 60 minutes. The label is whether the subsequent 30-minute sum exceeds the requested threshold. Train: sampled 2017–2022; validation: sampled 2023; test: sampled 2024. Spark MLlib logistic regression was fitted on thresholds 0,1,2,5,10 mm; per-threshold logistic calibrators were fitted on 2023. The held-out 2024 pooled raw model scores reported in the notebook were ROC-AUC 0.9063 and PR-AUC 0.4076. The calibration and baseline comparisons are recorded in the notebook.

## Important limitations
- The source archive alone is not a complete Canvas submission: include model directories, figures, and the final PDF report.
- Exported notebook cells have not been rerun in a fresh Colab session.
- Predictions at interpolated thresholds are not independently calibrated.
- The model uses rainfall readings through prediction time; real-time availability/latency is not guaranteed.
- Missing intervals and station coverage can bias estimates; EDA is descriptive, not official climatology.
- AI assistance was used for code drafting, debugging, methodological guidance, visualization, and documentation; verify this declaration against actual usage.
