"""
Unit and Integration Tests for RainCastSG Enhanced.
"""
import unittest
import math
from pathlib import Path

class TestInferenceLogic(unittest.TestCase):
    def test_risk_level_mapping(self):
        from RainCastSG_Enhanced.src.utils import get_risk_level
        self.assertEqual(get_risk_level(0.02), "Low (Unlikely)")
        self.assertEqual(get_risk_level(0.12), "Moderate (Possible)")
        self.assertEqual(get_risk_level(0.35), "Elevated (Likely)")
        self.assertEqual(get_risk_level(0.65), "High (Very Likely)")
        self.assertEqual(get_risk_level(0.85), "Severe / Imminent")

    def test_piecewise_linear_interpolation(self):
        # Test interpolation formula
        lo, hi = 2.0, 5.0
        p_lo, p_hi = 0.08, 0.02
        threshold = 3.5
        weight = (threshold - lo) / (hi - lo)  # 1.5 / 3.0 = 0.5
        p_interp = p_lo + weight * (p_hi - p_lo)
        self.assertAlmostEqual(p_interp, 0.05)

    def test_cyclical_encoding(self):
        # At hour 0, sin should be 0, cos should be 1
        h0_sin = math.sin(2 * math.pi * 0 / 24.0)
        h0_cos = math.cos(2 * math.pi * 0 / 24.0)
        self.assertAlmostEqual(h0_sin, 0.0)
        self.assertAlmostEqual(h0_cos, 1.0)

        # At hour 6, sin should be 1, cos should be 0
        h6_sin = math.sin(2 * math.pi * 6 / 24.0)
        h6_cos = math.cos(2 * math.pi * 6 / 24.0)
        self.assertAlmostEqual(h6_sin, 1.0)
        self.assertAlmostEqual(h6_cos, 0.0)

if __name__ == "__main__":
    unittest.main()
