# RainCastSG — Singapore Rainfall Analysis & 30-Minute Probabilistic Prediction

**Course:** DSA5208 — Scalable Distributed Computing for Data Science  
**Institution:** National University of Singapore (NUS)  
**Authors:**
- **Nithillen Jayaseelan** (Student ID: `[Student ID]`)
- **Amitej Singh** (Student ID: `[Student ID]`)
- **Ashwin Sasikumar** (Student ID: `[Student ID]`)

---

## 1. Executive Overview

**RainCastSG** is an end-to-end, scalable distributed data processing and machine learning pipeline developed with **Apache Spark (PySpark)** to investigate weather patterns across Singapore and predict short-horizon extreme rainfall occurrences.

The project addresses two core tasks:
1. **Task 1 — Exploratory Rainfall Analysis:** Investigate annual, seasonal (monsoonal), diurnal (afternoon convective), intensity (right-skewed tails), and spatial rainfall variations across 2017–2024 using 46.8 million high-frequency 5-minute station records from the National Environment Agency (data.gov.sg collection 2279).
2. **Task 2 — Probabilistic Rainfall Prediction:** Build a machine learning pipeline that estimates the probability $P(R_{t \to t+30\text{min}} > x \mid \text{station}, \text{time}, \text{history})$ that a monitoring station will accumulate more than a user-specified threshold $x \in [0, 10]\text{ mm}$ over the subsequent 30 minutes, evaluated chronologically using Spark MLlib with threshold-specific Platt-scaling probability calibration.

---

## 2. Directory Structure

```text
RainCastSG_Enhanced/
├── README.md                          # Comprehensive user guide & documentation
├── requirements.txt                   # Environment dependencies
├── src/                               # Modular, standalone Spark executable scripts
│   ├── __init__.py
│   ├── utils.py                       # SparkSession factory, timezone config, helpers
│   ├── ingest.py                      # Data ingestion & schema deduplication CLI
│   ├── eda.py                         # Spark SQL Task 1 exploratory analysis CLI
│   ├── features.py                    # 5m rolling accumulation & cyclical time ETL
│   ├── train.py                       # Spark MLlib LR pipeline & calibrator training
│   ├── evaluate.py                    # ROC-AUC, PR-AUC, Brier score benchmarking CLI
│   ├── predict.py                     # Operational historical & scenario inference CLI
│   └── pipeline.py                    # Master orchestrator runner
├── models/                            # Trained Spark MLlib models (included & ready-to-run)
│   ├── raincast_final_lr/             # PipelineModel (StringIndexer + OHE + Assembler + LR)
│   ├── calibrator_0mm/                # Platt logistic calibrator for > 0.0 mm
│   ├── calibrator_1mm/                # Platt logistic calibrator for > 1.0 mm
│   ├── calibrator_2mm/                # Platt logistic calibrator for > 2.0 mm
│   ├── calibrator_5mm/                # Platt logistic calibrator for > 5.0 mm
│   └── calibrator_10mm/               # Platt logistic calibrator for > 10.0 mm
├── data/sample/                       # Included sample datasets for instant verification
│   ├── sample_features.csv            # Pre-extracted multi-station feature rows
│   └── sample_raw_rainfall.csv        # Raw 5-minute station observation samples
├── figures/                           # 9 high-resolution analysis & evaluation figures
│   ├── annual_rainfall.png            # Mean observed annual rainfall per station
│   ├── monthly_seasonality.png        # 8-year monthly seasonal cycle
│   ├── rainfall_heatmap.png           # Year-by-month estimated daily rainfall heatmap
│   ├── hourly_rainfall.png            # Diurnal convective peak curve (15:00-16:00 SGT)
│   ├── rainfall_intensity.png         # Skewed non-zero rainfall intensity distribution
│   ├── spatial_rainfall.png           # Station coordinates & mean rainfall scatter
│   ├── spatial_rainfall_map.png       # Geographic station map over Singapore boundary
│   ├── threshold_performance.png      # Threshold-specific ROC-AUC & PR-AUC curves
│   └── baseline_vs_model.png          # Brier score error reduction vs baseline
└── results/                           # Evaluation metrics, calibration summaries & environment
    ├── baseline_comparison.csv
    ├── calibration_summary.csv
    ├── final_calibration_comparison.csv
    ├── final_model_comparison.csv
    ├── threshold_evaluation.csv
    └── environment.txt
```

---

## 3. Environment & Prerequisites

- **Python:** 3.10 – 3.13
- **Java:** OpenJDK 11 or 17
- **Apache Spark / PySpark:** 4.0.4 (or 3.5.x)
- **Timezone:** Standardized to `Asia/Singapore` (`SGT`, UTC+8)

To install dependencies:
```bash
pip install -r requirements.txt
```

---

## 4. Operational Inference (`predict.py`)

The inference CLI estimates the 30-minute threshold exceedance probability for any station, prediction time, and threshold $x \in [0, 10]\text{ mm}$.

### A. Run Inference on Bundled Historical Samples
The repository includes pre-packaged sample features, allowing immediate execution without downloading the full 47M-row dataset:

```bash
# Query Station S06 on 7 Nov 2024 for threshold > 3.5 mm (interpolated)
python src/predict.py --station S06 --time '2024-11-07 16:45:00' --threshold 3.5
```

**Sample Output:**
```text
=======================================================
   RainCastSG — 30-Minute Rainfall Probability Forecast
=======================================================
 Monitoring Station:       S06
 Prediction Timestamp:     2024-11-07 16:45:00 (SGT)
 Accumulation Horizon:     Next 30 minutes
 Rainfall Threshold:       > 3.5 mm
-------------------------------------------------------
 Exceedance Probability:   6.24% (0.062363)
 Operational Risk Level:   Moderate (Possible)
 Calibration Methodology:  Piecewise linear interpolation between calibrated 2.0mm and 5.0mm knots
 Observation Source:       Retrieved from historical feature database
 Prior Rainfall Profile:
   • Past  5min: 0.00 mm
   • Past 15min: 0.20 mm
   • Past 30min: 0.40 mm
   • Past 60min: 0.80 mm
=======================================================
```

### B. Direct Scenario Forecasting (No Database Lookup Required)
Users can simulate live forecasting scenarios by providing recent rainfall readings directly:
```bash
python src/predict.py --station S24 --time '2024-11-07 16:45:00' --threshold 5.0 \
    --rain-5m 1.4 --rain-15m 4.2 --rain-30m 8.6 --rain-60m 14.2 \
    --format json
```

---

## 5. End-to-End Pipeline Reproduction

### Step 1: Data Ingestion (`src/ingest.py`)
Downloads annual datasets from data.gov.sg, standardizes column types, resolves conflicting timestamps by update rank, and outputs Snappy-compressed Parquet:
```bash
python src/ingest.py --years 2024 --output-dir processed
# Or process all 8 years (requires internet access & ~15GB disk):
# python src/ingest.py --all-years --output-dir processed
```

### Step 2: Exploratory Data Analysis (`src/eda.py`)
Computes annual, seasonal, diurnal, intensity, and spatial statistics via Spark SQL and generates publication figures:
```bash
python src/eda.py --data-dir processed --figures-dir figures --results-dir results
```

### Step 3: Feature Engineering (`src/features.py`)
Computes 5-minute rolling sums (`rain_5m`, `rain_15m`, `rain_30m`, `rain_60m`), future 30-minute target accumulations, and verifies exact 5-minute consecutive spacing:
```bash
python src/features.py --data-dir processed --output-path processed/features_all
```

### Step 4: Model Training (`src/train.py`)
Performs chronological partitioning (2017–2022 Train, 2023 Validation, 2024 Test), trains the Spark MLlib Logistic Regression pipeline, and fits Platt calibrators on 2023 log-odds:
```bash
python src/train.py --features-path processed/features_all --model-dir models --sample-train 0.05 --sample-val 0.10
```

### Step 5: Model Evaluation & Benchmarking (`src/evaluate.py`)
Evaluates the held-out 2024 test set, calculates pooled ROC-AUC and PR-AUC, compares Brier scores against training-frequency baselines, and verifies probability monotonicity:
```bash
python src/evaluate.py --features-path processed/features_all --model-dir models --results-dir results
```

---

## 6. Performance & Benchmark Summary

Evaluated on the held-out 2024 test dataset (633,357 sampled station-time observations):

- **Discrimination:**
  - **Pooled ROC-AUC:** `0.9063` (Validation: `0.9101`)
  - **Pooled PR-AUC:** `0.4076` (Validation: `0.4155`)
- **Calibration & Brier Score Comparison:**
  Platt-scaling probability calibration significantly reduced Brier score error relative to an historical-frequency baseline across all five target thresholds:

| Threshold ($x$) | Actual Rate (%) | Raw MLlib Brier | Calibrated Brier | Baseline Brier | Brier Error Reduction |
|:---:|:---:|:---:|:---:|:---:|:---:|
| **> 0.0 mm** | 6.362% | 0.05468 | **0.04119** | 0.05958 | **30.9%** |
| **> 1.0 mm** | 2.567% | 0.02024 | **0.01843** | 0.02502 | **26.3%** |
| **> 2.0 mm** | 1.708% | 0.01319 | **0.01292** | 0.01679 | **23.1%** |
| **> 5.0 mm** | 0.834% | 0.00696 | **0.00685** | 0.00827 | **17.2%** |
| **> 10.0 mm**| 0.374% | 0.00414 | **0.00332** | 0.00373 | **11.0%** |

- **Monotonicity Verification:** 100% of tested observations satisfied $P(R > x_1) \ge P(R > x_2)$ for $x_1 \le x_2$ (0 ordering violations among 633,357 test rows).

---

## 7. Academic Integrity & AI-Use Declaration

This project complies strictly with the **NUS Plagiarism Policy**, the **NUS Code of Student Conduct (Section A: Academic Integrity)**, and the **Policy for Use of AI in Teaching and Learning (Sections 3 and 4)**.

### AI Tool Usage Declaration
> We utilized Generative AI tools (**ChatGPT** and **Google Gemini**) to assist with:
> 1. Formulating cyclical trigonometric encodings for diurnal and annual temporal features;
> 2. Refactoring exploratory Jupyter notebook snippets into modular, standalone Spark CLI scripts with robust argument parsing and error handling;
> 3. Designing formatting templates for tabular metrics and report document structure;
> 4. Reviewing paragraph clarity and refining academic expressions in draft sections of the report.
>
> All data ingestion, exploratory Spark SQL analyses, experimental configurations on Google Colab, model training runs, calibration validations, and meteorological interpretations were designed, executed, and verified by the authors. We take full responsibility for the content, code, and quality of the submitted work.
>
> **Group Members:**  
> - Nithillen Jayaseelan  
> - Amitej Singh  
> - Ashwin Sasikumar  
