"""
Shared utilities, Spark session configuration, and constants for RainCastSG.
"""
import sys
import logging
from pathlib import Path

# Supported probability calibration knots (mm)
KNOTS = (0.0, 1.0, 2.0, 5.0, 10.0)

# NEA Historical Rainfall dataset IDs on data.gov.sg (collection 2279)
DATASET_IDS = {
    2017: "d_584c36d0bc650e82c5f6e80b2d69e46a",
    2018: "d_163273e04e93fb239c80df7a0ec449c4",
    2019: "d_8dfb5a40b3367123aa176ea3ca2e21b0",
    2020: "d_60533cc283c7b6c7a9507119156efcb2",
    2021: "d_7e57c6b414f6b3e839e44ea88db8fa62",
    2022: "d_1963ea75e468fb79dfda5f69c0dcf75d",
    2023: "d_9d424ca54eb0c16366050b4ec2b557b7",
    2024: "d_73229b4fa4cb048126b86cf01b0f5b13",
}

def setup_logger(name: str = "RainCastSG", level: int = logging.INFO) -> logging.Logger:
    """Configures and returns a standardized logger."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] [%(name)s]: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger

def get_spark_session(
    app_name: str = "RainCastSG",
    master: str = "local[2]",
    timezone: str = "Asia/Singapore",
    shuffle_partitions: int = 16,
    log_level: str = "WARN"
):
    """
    Initializes and returns an Apache SparkSession configured for Singapore rainfall analysis.
    
    Args:
        app_name: Name of the Spark application.
        master: Spark master URL (default 'local[2]' for dual-core local execution).
        timezone: SQL session timezone (standardized to 'Asia/Singapore').
        shuffle_partitions: Number of shuffle partitions for balanced distributed joins/aggs.
        log_level: Log verbosity (default 'WARN' to suppress verbose Spark internal info).
    """
    try:
        from pyspark.sql import SparkSession
    except ImportError as e:
        raise ImportError(
            "PySpark is not installed in the current environment. "
            "Please install it using 'pip install pyspark==4.0.4' or run within your Spark cluster."
        ) from e

    spark = (
        SparkSession.builder
        .appName(app_name)
        .master(master)
        .config("spark.sql.session.timeZone", timezone)
        .config("spark.sql.shuffle.partitions", str(shuffle_partitions))
        .config("spark.driver.memory", "4g")
        .config("spark.ui.showConsoleProgress", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel(log_level)
    return spark

def get_risk_level(probability: float) -> str:
    """Categorizes rainfall probability into operational meteorological risk tiers."""
    if probability < 0.05:
        return "Low (Unlikely)"
    elif probability < 0.20:
        return "Moderate (Possible)"
    elif probability < 0.50:
        return "Elevated (Likely)"
    elif probability < 0.80:
        return "High (Very Likely)"
    else:
        return "Severe / Imminent"
