"""
Model Training Pipeline for RainCastSG (Task 2).

Trains Spark MLlib Logistic Regression model across multiple threshold levels,
and fits threshold-specific Platt-scaling calibrators on validation log-odds.
"""
import argparse
from pathlib import Path
from pyspark.sql import functions as F
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, OneHotEncoder, VectorAssembler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.functions import vector_to_array

try:
    from .utils import get_spark_session, setup_logger, KNOTS
    from .features import add_cyclical_features
except ImportError:
    from utils import get_spark_session, setup_logger, KNOTS
    from features import add_cyclical_features

logger = setup_logger("Train")

def create_threshold_labels(df, thresholds=KNOTS):
    """Explodes each observation across candidate rainfall thresholds and creates binary target labels."""
    th_array = F.array([F.lit(t) for t in thresholds])
    return (
        df
        .withColumn("threshold_mm", F.explode(th_array))
        .withColumn("label", (F.col("future_30m") > F.col("threshold_mm")).cast("double"))
    )

def train_base_model(train_df, reg_param: float = 0.05, max_iter: int = 30):
    """Builds and fits the core Spark MLlib Logistic Regression pipeline."""
    logger.info("Assembling Spark MLlib Pipeline stages...")
    indexer = StringIndexer(inputCol="station_id", outputCol="station_index", handleInvalid="keep")
    encoder = OneHotEncoder(inputCols=["station_index"], outputCols=["station_vector"])
    assembler = VectorAssembler(
        inputCols=[
            "station_vector",
            "hour_sin", "hour_cos",
            "month_sin", "month_cos",
            "rain_5m", "rain_15m",
            "rain_30m", "rain_60m",
            "threshold_mm"
        ],
        outputCol="features"
    )
    lr = LogisticRegression(
        featuresCol="features",
        labelCol="label",
        maxIter=max_iter,
        regParam=reg_param
    )
    pipeline = Pipeline(stages=[indexer, encoder, assembler, lr])
    logger.info(f"Fitting base logistic regression pipeline (regParam={reg_param}, maxIter={max_iter})...")
    return pipeline.fit(train_df)

def train_calibrators(val_df, base_model, thresholds=KNOTS):
    """Fits univariate Platt-scaling logistic calibrators mapping raw logit -> calibrated probability."""
    logger.info("Computing raw model predictions on validation set for probability calibration...")
    scored_val = (
        base_model.transform(val_df)
        .withColumn("p_raw", vector_to_array("probability")[1])
        .select("threshold_mm", "label", "p_raw")
    )

    # Compute raw log-odds (clipping extreme values for numerical stability)
    p_clipped = F.greatest(F.lit(1e-6), F.least(F.col("p_raw"), F.lit(1.0 - 1e-6)))
    val_with_logit = scored_val.withColumn("logit_raw", F.log(p_clipped / (1.0 - p_clipped)))

    assembler = VectorAssembler(inputCols=["logit_raw"], outputCol="cal_features")
    calibrators = {}

    for t in thresholds:
        logger.info(f"Fitting logistic calibrator for threshold {t:.1f} mm...")
        subset = val_with_logit.filter(F.col("threshold_mm") == t)
        prepared = assembler.transform(subset)
        calibrator = LogisticRegression(
            featuresCol="cal_features",
            labelCol="label",
            maxIter=30,
            regParam=0.001
        )
        calibrators[t] = calibrator.fit(prepared)

    return calibrators

def main():
    parser = argparse.ArgumentParser(description="Train Spark MLlib model and probability calibrators.")
    parser.add_argument("--features-path", type=str, default="processed/features_all", help="Feature store parquet path")
    parser.add_argument("--model-dir", type=str, default="models", help="Directory to save trained models")
    parser.add_argument("--sample-train", type=float, default=0.05, help="Sampling fraction for training set")
    parser.add_argument("--sample-val", type=float, default=0.10, help="Sampling fraction for validation set")
    parser.add_argument("--reg-param", type=float, default=0.05, help="Logistic regression L2 regularization parameter")
    parser.add_argument("--max-iter", type=int, default=30, help="Maximum training iterations")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for sampling")
    args = parser.parse_args()

    spark = get_spark_session(app_name="RainCastSG-Train")
    try:
        model_dir = Path(args.model_dir)
        model_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"Loading features from {args.features_path}...")
        all_features = spark.read.parquet(args.features_path)

        # Chronological partition
        train_base = all_features.filter(F.col("time_bucket") < "2022-12-31 23:30:00")
        val_base = all_features.filter(
            (F.col("time_bucket") >= "2023-01-01 00:00:00") &
            (F.col("time_bucket") < "2023-12-31 23:30:00")
        )

        if args.sample_train < 1.0:
            logger.info(f"Subsampling training base to {args.sample_train*100:.1f}% (seed={args.seed})...")
            train_base = train_base.sample(False, args.sample_train, seed=args.seed)
        if args.sample_val < 1.0:
            logger.info(f"Subsampling validation base to {args.sample_val*100:.1f}% (seed={args.seed})...")
            val_base = val_base.sample(False, args.sample_val, seed=args.seed)

        # Expand thresholds & add cyclical features
        train_df = add_cyclical_features(create_threshold_labels(train_base))
        val_df = add_cyclical_features(create_threshold_labels(val_base))

        base_model = train_base_model(train_df, reg_param=args.reg_param, max_iter=args.max_iter)
        base_path = model_dir / "raincast_final_lr"
        logger.info(f"Saving base model pipeline to {base_path}...")
        base_model.write().overwrite().save(str(base_path))

        calibrators = train_calibrators(val_df, base_model)
        for t, cal in calibrators.items():
            cal_path = model_dir / f"calibrator_{int(t)}mm"
            logger.info(f"Saving calibrator ({t} mm) to {cal_path}...")
            cal.write().overwrite().save(str(cal_path))

        logger.info("Training and calibration pipeline successfully completed!")
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
