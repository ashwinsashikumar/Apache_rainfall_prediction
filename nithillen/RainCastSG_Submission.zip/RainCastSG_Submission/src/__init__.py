"""RainCastSG: Singapore Rainfall Analysis and Probabilistic Prediction with Apache Spark."""
__version__ = "2.0.0"
