"""
Unified Pipeline Orchestrator for RainCastSG.

Provides convenient commands to run inference demos, model evaluation,
and full workflow replication.
"""
import argparse
import sys
from pathlib import Path

def run_demo(base_dir: Path):
    """Executes verification predictions across multiple stations and thresholds."""
    print("Executing RainCastSG Demonstration Inferences...")
    test_cases = [
        {"station": "S06", "time": "2024-11-07 16:45:00", "threshold": 5.0},
        {"station": "S06", "time": "2024-11-07 16:45:00", "threshold": 3.5},
        {"station": "S104", "time": "2024-11-07 15:30:00", "threshold": 2.0},
        {"station": "S50", "time": "2024-06-20 10:15:00", "threshold": 0.0},
    ]

    from predict import predict_exceedance
    from utils import get_spark_session

    spark = get_spark_session(app_name="RainCastSG-Demo", master="local[1]", log_level="ERROR")
    try:
        for tc in test_cases:
            res = predict_exceedance(
                spark=spark,
                base_dir=base_dir,
                station=tc["station"],
                time_sgt=tc["time"],
                threshold=tc["threshold"]
            )
            print(f"Station {res['station_id']} @ {res['prediction_time_sgt']} | Threshold > {res['threshold_mm']} mm: "
                  f"Probability = {res['probability_percentage']} [{res['risk_level']}]")
    finally:
        spark.stop()

def main():
    parser = argparse.ArgumentParser(description="RainCastSG Master Orchestration Runner.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    demo_parser = subparsers.add_parser("demo", help="Run quick demo inference across sample stations")
    demo_parser.add_argument("--base", type=str, default=".", help="Base project directory")

    args = parser.parse_args()
    base_dir = Path(args.base).resolve()

    if args.command == "demo":
        run_demo(base_dir)

if __name__ == "__main__":
    main()
