"""
Feature Engineering Pipeline for RainCastSG (Task 2).

Transforms 5-minute rainfall readings into rolling past accumulation features
(5m, 15m, 30m, 60m), future 30m target accumulation, and cyclical temporal encodings.
"""
import argparse
import math
from pathlib import Path
from pyspark.sql import functions as F
from pyspark.sql.window import Window

try:
    from .utils import get_spark_session, setup_logger
except ImportError:
    from utils import get_spark_session, setup_logger

logger = setup_logger("Features")

def build_features(spark, raw_df):
    """
    Constructs rolling window features and future 30-minute accumulation targets.
    
    Window definitions over chronological 5-minute station buckets:
      - rain_5m: current 5m reading
      - rain_15m: sum of current + 2 preceding readings (rowsBetween -2 to 0)
      - rain_30m: sum of current + 5 preceding readings (rowsBetween -5 to 0)
      - rain_60m: sum of current + 11 preceding readings (rowsBetween -11 to 0)
      - future_30m: sum of next 6 readings (rowsBetween 1 to 6)
    """
    logger.info("Normalizing observations into exact 5-minute time buckets...")
    bucketed = raw_df.select(
        "station_id",
        "rainfall_mm",
        F.timestamp_seconds(
            F.floor(F.unix_timestamp("timestamp_sgt") / 300) * 300
        ).alias("time_bucket")
    )

    # Average any multiple readings within the same 5m bucket
    bucketed = bucketed.groupBy("station_id", "time_bucket").agg(
        F.avg("rainfall_mm").alias("rainfall_mm")
    )

    w = Window.partitionBy("station_id").orderBy("time_bucket")

    logger.info("Calculating rolling accumulation windows and future 30m targets...")
    features = (
        bucketed
        .withColumn("rain_5m", F.col("rainfall_mm"))
        .withColumn("rain_15m", F.sum("rainfall_mm").over(w.rowsBetween(-2, 0)))
        .withColumn("rain_30m", F.sum("rainfall_mm").over(w.rowsBetween(-5, 0)))
        .withColumn("rain_60m", F.sum("rainfall_mm").over(w.rowsBetween(-11, 0)))
        .withColumn("future_30m", F.sum("rainfall_mm").over(w.rowsBetween(1, 6)))
        .withColumn("past_time", F.lag("time_bucket", 11).over(w))
        .withColumn("future_time", F.lead("time_bucket", 6).over(w))
    )

    # Continuity constraint: enforce strict consecutive 5m intervals (55m past span, 30m future span)
    logger.info("Applying strict temporal continuity filters (no missing intervals permitted)...")
    valid_features = features.filter(
        (F.unix_timestamp("time_bucket") - F.unix_timestamp("past_time") == 3300) &
        (F.unix_timestamp("future_time") - F.unix_timestamp("time_bucket") == 1800)
    )

    final_df = (
        valid_features
        .withColumn("year", F.year("time_bucket"))
        .withColumn("month", F.month("time_bucket"))
        .withColumn("hour", F.hour("time_bucket"))
        .select(
            "station_id", "time_bucket", "year", "month", "hour",
            "rain_5m", "rain_15m", "rain_30m", "rain_60m", "future_30m"
        )
    )
    return final_df

def add_cyclical_features(df):
    """Enriches DataFrame with trigonometric sine and cosine encodings for hour and month."""
    return (
        df
        .withColumn("hour_sin", F.sin(2 * math.pi * F.col("hour") / 24))
        .withColumn("hour_cos", F.cos(2 * math.pi * F.col("hour") / 24))
        .withColumn("month_sin", F.sin(2 * math.pi * F.col("month") / 12))
        .withColumn("month_cos", F.cos(2 * math.pi * F.col("month") / 12))
    )

def main():
    parser = argparse.ArgumentParser(description="Build feature store for rainfall threshold prediction.")
    parser.add_argument("--data-dir", type=str, default="processed", help="Directory with processed Parquet partitions")
    parser.add_argument("--output-path", type=str, default="processed/features_all", help="Output path for feature store")
    args = parser.parse_args()

    spark = get_spark_session(app_name="RainCastSG-Features")
    try:
        data_path = Path(args.data_dir)
        partitions = [str(p) for p in data_path.glob("rainfall_*")]
        if not partitions:
            logger.error(f"No rainfall Parquet partitions found in {data_path}")
            return

        logger.info(f"Loading {len(partitions)} yearly rainfall partitions...")
        raw_all = spark.read.parquet(*partitions)
        features_all = build_features(spark, raw_all)

        output_path = Path(args.output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        logger.info(f"Saving feature store to {output_path}...")
        (
            features_all.write
            .mode("overwrite")
            .option("compression", "snappy")
            .parquet(str(output_path))
        )
        logger.info("Feature pipeline completed successfully!")
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
