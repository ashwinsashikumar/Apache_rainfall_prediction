"""
Operational Inference CLI for RainCastSG (Task 2).

Estimates the probability that a Singapore monitoring station will accumulate
more than a given rainfall threshold in the subsequent 30 minutes.

Usage:
  # Historical database lookup:
  python src/predict.py --station S06 --time '2024-11-07 16:45:00' --threshold 3.5

  # Direct feature scenario specification (no database lookup required):
  python src/predict.py --station S06 --time '2024-11-07 16:45:00' --threshold 5.0 \
      --rain-5m 0.0 --rain-15m 0.2 --rain-30m 0.4 --rain-60m 0.8
"""
import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

from pyspark.sql import SparkSession, functions as F
from pyspark.ml import PipelineModel
from pyspark.ml.classification import LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.functions import vector_to_array

try:
    from .utils import get_spark_session, setup_logger, get_risk_level, KNOTS
except ImportError:
    from utils import get_spark_session, setup_logger, get_risk_level, KNOTS

logger = setup_logger("Predict")

def find_feature_row(spark, base_dir: Path, station: str, time_sgt: str, data_source: Optional[str] = None):
    """Searches for station/time features in available feature stores or sample datasets."""
    candidate_paths = []
    if data_source:
        candidate_paths.append(Path(data_source))
    
    # Priority paths: user processed store, then bundled sample data
    candidate_paths.extend([
        base_dir / "processed" / "features_all",
        base_dir / "data" / "sample" / "sample_features.csv",
        base_dir / "RainCastSG_Enhanced" / "data" / "sample" / "sample_features.csv",
    ])

    for p in candidate_paths:
        if not p.exists():
            continue
        try:
            if p.suffix == ".csv" or (p.is_file() and str(p).endswith(".csv")):
                df = spark.read.option("header", True).option("inferSchema", True).csv(str(p))
            else:
                df = spark.read.parquet(str(p))

            matched = (
                df.filter(
                    (F.col("station_id") == station) &
                    (F.col("time_bucket") == F.to_timestamp(F.lit(time_sgt)))
                )
                .select("station_id", "time_bucket", "hour", "month", "rain_5m", "rain_15m", "rain_30m", "rain_60m")
                .limit(1)
                .collect()
            )
            if matched:
                logger.info(f"Loaded observation features for station {station} at {time_sgt} from {p.name}")
                return matched[0].asDict()
        except Exception as e:
            logger.debug(f"Could not read candidate feature source {p}: {e}")

    return None

def predict_exceedance(
    spark,
    base_dir: Path,
    station: str,
    time_sgt: str,
    threshold: float,
    rain_features: Optional[Dict[str, float]] = None,
    data_source: Optional[str] = None
) -> Dict[str, Any]:
    """
    Computes calibrated probability that next 30m rainfall > threshold.
    """
    if not (0.0 <= threshold <= 10.0):
        raise ValueError(f"Rainfall threshold must be within [0.0, 10.0] mm (received {threshold})")

    # Locate trained models
    model_dir = base_dir / "models"
    if not model_dir.exists():
        model_dir = base_dir / "RainCastSG_Enhanced" / "models"
    
    base_model_path = model_dir / "raincast_final_lr"
    if not base_model_path.exists():
        raise FileNotFoundError(f"Trained base model not found at {base_model_path}")

    # Determine observation feature values
    parsed_dt = datetime.strptime(time_sgt, "%Y-%m-%d %H:%M:%S")
    hour = parsed_dt.hour
    month = parsed_dt.month

    if rain_features is not None:
        r5 = float(rain_features.get("rain_5m", 0.0))
        r15 = float(rain_features.get("rain_15m", r5))
        r30 = float(rain_features.get("rain_30m", r15))
        r60 = float(rain_features.get("rain_60m", r30))
        source_note = "User-specified prior rainfall features"
    else:
        row_dict = find_feature_row(spark, base_dir, station, time_sgt, data_source)
        if not row_dict:
            raise ValueError(
                f"No historical record found for station '{station}' at '{time_sgt}'. "
                f"You can provide direct prior rainfall using --rain-5m, --rain-15m, --rain-30m, --rain-60m, "
                f"or test with bundled sample station S06 at '2024-11-07 16:45:00'."
            )
        hour = int(row_dict.get("hour", hour))
        month = int(row_dict.get("month", month))
        r5 = float(row_dict["rain_5m"])
        r15 = float(row_dict["rain_15m"])
        r30 = float(row_dict["rain_30m"])
        r60 = float(row_dict["rain_60m"])
        source_note = "Retrieved from historical feature database"

    # Build single-row Spark DataFrame with cyclical time features
    x_data = [(
        station,
        time_sgt,
        hour,
        month,
        math.sin(2 * math.pi * hour / 24.0),
        math.cos(2 * math.pi * hour / 24.0),
        math.sin(2 * math.pi * month / 12.0),
        math.cos(2 * math.pi * month / 12.0),
        r5, r15, r30, r60
    )]
    schema = [
        "station_id", "time_bucket", "hour", "month",
        "hour_sin", "hour_cos", "month_sin", "month_cos",
        "rain_5m", "rain_15m", "rain_30m", "rain_60m"
    ]
    x_df = spark.createDataFrame(x_data, schema)

    # Load Spark MLlib base pipeline
    base_model = PipelineModel.load(str(base_model_path))
    cal_assembler = VectorAssembler(inputCols=["logit_raw"], outputCol="cal_features")

    # Determine required calibration knots
    if threshold in KNOTS:
        needed_knots = [threshold]
    else:
        lo = max(k for k in KNOTS if k < threshold)
        hi = min(k for k in KNOTS if k > threshold)
        needed_knots = [lo, hi]

    calibrated_probs = {}
    for knot in needed_knots:
        # Score through base model with threshold_mm set to knot
        scored = base_model.transform(x_df.withColumn("threshold_mm", F.lit(knot)))
        scored = scored.withColumn("p_raw", vector_to_array("probability")[1])
        
        # Safe logit computation
        p_safe = F.greatest(F.lit(1e-6), F.least(F.col("p_raw"), F.lit(1.0 - 1e-6)))
        scored_logit = cal_assembler.transform(scored.withColumn("logit_raw", F.log(p_safe / (1.0 - p_safe))))
        
        cal_path = model_dir / f"calibrator_{int(knot)}mm"
        if cal_path.exists():
            calibrator = LogisticRegressionModel.load(str(cal_path))
            cal_res = calibrator.transform(scored_logit)
            p_val = float(cal_res.select(vector_to_array("probability")[1].alias("p")).first()["p"])
        else:
            p_val = float(scored.first()["p_raw"])

        calibrated_probs[knot] = p_val

    # Piecewise linear interpolation for thresholds between knots
    if len(needed_knots) == 1:
        final_probability = calibrated_probs[needed_knots[0]]
        method = "Direct Platt-calibrated logistic model"
    else:
        lo, hi = needed_knots
        p_lo, p_hi = calibrated_probs[lo], calibrated_probs[hi]
        weight = (threshold - lo) / (hi - lo)
        final_probability = p_lo + weight * (p_hi - p_lo)
        method = f"Piecewise linear interpolation between calibrated {lo}mm and {hi}mm knots"

    # Enforce valid range [0, 1]
    final_probability = max(0.0, min(1.0, final_probability))

    return {
        "station_id": station,
        "prediction_time_sgt": time_sgt,
        "threshold_mm": threshold,
        "horizon_minutes": 30,
        "probability": round(final_probability, 6),
        "probability_percentage": f"{final_probability * 100.0:.2f}%",
        "risk_level": get_risk_level(final_probability),
        "calibration_method": method,
        "prior_rainfall_mm": {
            "5min": r5,
            "15min": r15,
            "30min": r30,
            "60min": r60
        },
        "source": source_note
    }

def main():
    parser = argparse.ArgumentParser(description="RainCastSG: 30-Minute Rainfall Threshold Exceedance Predictor.")
    parser.add_argument("--base", type=str, default=".", help="Base project directory")
    parser.add_argument("--station", type=str, required=True, help="Singapore station ID (e.g. S06, S24, S104)")
    parser.add_argument("--time", type=str, required=True, help="Prediction time SGT (format: 'YYYY-MM-DD HH:MM:SS')")
    parser.add_argument("--threshold", type=float, required=True, help="Rainfall threshold in mm (0.0 to 10.0)")
    parser.add_argument("--data-source", type=str, default=None, help="Optional feature store or sample CSV path")
    parser.add_argument("--rain-5m", type=float, default=None, help="Optional direct 5-min prior rainfall (mm)")
    parser.add_argument("--rain-15m", type=float, default=None, help="Optional direct 15-min prior rainfall (mm)")
    parser.add_argument("--rain-30m", type=float, default=None, help="Optional direct 30-min prior rainfall (mm)")
    parser.add_argument("--rain-60m", type=float, default=None, help="Optional direct 60-min prior rainfall (mm)")
    parser.add_argument("--format", choices=["json", "summary"], default="summary", help="Output display format")
    args = parser.parse_args()

    rain_features = None
    if args.rain_5m is not None:
        rain_features = {
            "rain_5m": args.rain_5m,
            "rain_15m": args.rain_15m if args.rain_15m is not None else args.rain_5m,
            "rain_30m": args.rain_30m if args.rain_30m is not None else args.rain_5m,
            "rain_60m": args.rain_60m if args.rain_60m is not None else args.rain_5m
        }

    base_dir = Path(args.base).resolve()
    spark = get_spark_session(app_name="RainCastSG-Inference", master="local[1]", log_level="ERROR")

    try:
        result = predict_exceedance(
            spark=spark,
            base_dir=base_dir,
            station=args.station,
            time_sgt=args.time,
            threshold=args.threshold,
            rain_features=rain_features,
            data_source=args.data_source
        )

        if args.format == "json":
            print(json.dumps(result, indent=2))
        else:
            print("\n=======================================================")
            print("   RainCastSG — 30-Minute Rainfall Probability Forecast")
            print("=======================================================")
            print(f" Monitoring Station:       {result['station_id']}")
            print(f" Prediction Timestamp:     {result['prediction_time_sgt']} (SGT)")
            print(f" Accumulation Horizon:     Next {result['horizon_minutes']} minutes")
            print(f" Rainfall Threshold:       > {result['threshold_mm']} mm")
            print("-------------------------------------------------------")
            print(f" Exceedance Probability:   {result['probability_percentage']} ({result['probability']:.6f})")
            print(f" Operational Risk Level:   {result['risk_level']}")
            print(f" Calibration Methodology:  {result['calibration_method']}")
            print(f" Observation Source:       {result['source']}")
            print(" Prior Rainfall Profile:")
            for k, v in result['prior_rainfall_mm'].items():
                print(f"   • Past {k:>5}: {v:.2f} mm")
            print("=======================================================\n")
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
