"""
Data Ingestion and Quality Auditing Pipeline for RainCastSG.

Downloads annual 5-minute rainfall CSVs from data.gov.sg (collection 2279),
cleans schemas, resolves duplicates by update timestamp, and saves Snappy Parquet.
"""
import argparse
import gc
import sys
from pathlib import Path
from typing import Optional, List

try:
    import requests
except ImportError:
    requests = None

from pyspark.sql import functions as F
from pyspark.sql.window import Window

try:
    from .utils import get_spark_session, setup_logger, DATASET_IDS
except ImportError:
    from utils import get_spark_session, setup_logger, DATASET_IDS

API_BASE = "https://api-open.data.gov.sg/v1/public/api"
logger = setup_logger("Ingest")

def download_year_csv(year: int, raw_dir: Path) -> Path:
    """Initiates and downloads a signed annual dataset CSV from data.gov.sg."""
    if requests is None:
        raise ImportError("The 'requests' package is required for downloading data. Run 'pip install requests'.")

    dataset_id = DATASET_IDS.get(year)
    if not dataset_id:
        raise ValueError(f"No dataset ID registered for year {year}")

    csv_path = raw_dir / f"rainfall_{year}.csv"
    if csv_path.exists() and csv_path.stat().st_size > 1024 * 1024:
        logger.info(f"Year {year}: Raw CSV already exists ({csv_path.stat().st_size / 1024**2:.1f} MB). Skipping download.")
        return csv_path

    logger.info(f"Year {year}: Requesting download URL from data.gov.sg API...")
    init = requests.get(f"{API_BASE}/datasets/{dataset_id}/initiate-download", timeout=90)
    init.raise_for_status()
    payload = init.json()
    if payload.get("code") != 0:
        raise RuntimeError(f"Download initiation failed: {payload}")

    download_url = payload["data"].get("url")
    if not download_url:
        raise RuntimeError(f"No download URL returned for {year}")

    logger.info(f"Year {year}: Streaming download to {csv_path}...")
    with requests.get(download_url, stream=True, timeout=(30, 180)) as r:
        r.raise_for_status()
        with open(csv_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=4 * 1024 * 1024):
                if chunk:
                    f.write(chunk)

    logger.info(f"Year {year}: Download completed ({csv_path.stat().st_size / 1024**2:.1f} MB).")
    return csv_path

def clean_and_process_year(spark, year: int, csv_path: Path, output_dir: Path, remove_csv: bool = False):
    """Parses raw CSV, validates values, deduplicates, and writes compressed Parquet."""
    output_path = output_dir / f"rainfall_{year}"
    if (output_path / "_SUCCESS").exists():
        logger.info(f"Year {year}: Parquet output already exists at {output_path}. Skipping.")
        return

    logger.info(f"Year {year}: Reading raw CSV into Spark DataFrame...")
    raw = spark.read.option("header", True).csv(str(csv_path))

    # Standardize column types
    typed = raw.select(
        F.to_timestamp("timestamp").alias("timestamp_sgt"),
        F.trim("station_id").alias("station_id"),
        F.col("station_name"),
        F.col("reading_value").cast("double").alias("rainfall_mm"),
        F.col("location_latitude").cast("double").alias("latitude"),
        F.col("location_longitude").cast("double").alias("longitude"),
        F.to_timestamp("reading_update_timestamp").alias("reading_updated_at"),
        F.col("reading_unit")
    )

    # Filter invalid records
    valid = typed.filter(
        F.col("timestamp_sgt").isNotNull() &
        F.col("station_id").isNotNull() &
        (F.col("station_id") != "") &
        F.col("rainfall_mm").isNotNull() &
        (F.col("rainfall_mm") >= 0) &
        (F.col("reading_unit") == "mm") &
        (F.year("timestamp_sgt") == year)
    )

    # Deterministic deduplication: prefer latest update timestamp, then highest reading
    window = Window.partitionBy("station_id", "timestamp_sgt").orderBy(
        F.col("reading_updated_at").desc_nulls_last(),
        F.col("rainfall_mm").desc(),
        F.col("station_name").asc_nulls_last()
    )

    clean = (
        valid
        .withColumn("_rank", F.row_number().over(window))
        .filter(F.col("_rank") == 1)
        .drop("_rank", "reading_updated_at", "reading_unit")
    )

    logger.info(f"Year {year}: Writing Snappy-compressed Parquet to {output_path}...")
    (
        clean.write
        .mode("overwrite")
        .option("compression", "snappy")
        .parquet(str(output_path))
    )

    # Verification summary
    saved = spark.read.parquet(str(output_path))
    stats = saved.agg(
        F.count("*").alias("rows"),
        F.countDistinct("station_id").alias("stations"),
        F.min("timestamp_sgt").alias("start"),
        F.max("timestamp_sgt").alias("end"),
        F.sum(F.when(F.col("rainfall_mm") > 0, 1).otherwise(0)).alias("wet_rows")
    ).first()

    logger.info(f"Year {year} Summary: {stats['rows']:,} rows, {stats['stations']} stations.")
    logger.info(f"Span: {stats['start']} -> {stats['end']} | Wet observations: {stats['wet_rows']:,}")

    if remove_csv and csv_path.exists():
        csv_path.unlink()
        logger.info(f"Year {year}: Temporary CSV removed.")

    del raw, typed, valid, clean, saved
    gc.collect()

def main():
    parser = argparse.ArgumentParser(description="Ingest Singapore Rainfall datasets into Parquet.")
    parser.add_argument("--years", nargs="+", type=int, default=[2024], help="Years to process (2017-2024)")
    parser.add_argument("--all-years", action="store_true", help="Process all years (2017 to 2024)")
    parser.add_argument("--raw-dir", type=str, default="data/raw", help="Directory for raw CSV downloads")
    parser.add_argument("--output-dir", type=str, default="processed", help="Directory for processed Parquet")
    parser.add_argument("--skip-download", action="store_true", help="Assume raw CSVs already exist")
    parser.add_argument("--keep-csv", action="store_true", help="Retain CSV files after writing Parquet")
    args = parser.parse_args()

    raw_dir = Path(args.raw_dir)
    output_dir = Path(args.output_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    years = list(range(2017, 2025)) if args.all_years else args.years
    spark = get_spark_session(app_name="RainCastSG-Ingest")

    try:
        for year in sorted(years):
            if args.skip_download:
                csv_path = raw_dir / f"rainfall_{year}.csv"
            else:
                csv_path = download_year_csv(year, raw_dir)
            clean_and_process_year(spark, year, csv_path, output_dir, remove_csv=not args.keep_csv)
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
