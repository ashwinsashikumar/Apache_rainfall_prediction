"""
Model Evaluation and Baseline Benchmarking for RainCastSG (Task 2).

Evaluates discrimination (ROC-AUC, PR-AUC), calibration (Brier scores),
and compares calibrated Spark MLlib predictions against an historical frequency baseline.
"""
import argparse
from pathlib import Path
from pyspark.sql import functions as F
from pyspark.ml import PipelineModel
from pyspark.ml.classification import LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.functions import vector_to_array

try:
    from .utils import get_spark_session, setup_logger, KNOTS
    from .features import add_cyclical_features
    from .train import create_threshold_labels
except ImportError:
    from utils import get_spark_session, setup_logger, KNOTS
    from features import add_cyclical_features
    from train import create_threshold_labels

logger = setup_logger("Evaluate")

def evaluate_test_set(spark, model_dir: Path, features_path: str, results_dir: Path, sample_test: float = 0.10, seed: int = 42):
    """Executes full evaluation on held-out 2024 test data."""
    logger.info(f"Loading feature store from {features_path}...")
    all_features = spark.read.parquet(features_path)

    # Historical training base for frequency baseline
    train_base = all_features.filter(F.col("time_bucket") < "2022-12-31 23:30:00")
    test_base = all_features.filter(F.col("time_bucket") >= "2024-01-01 00:00:00")

    if sample_test < 1.0:
        logger.info(f"Subsampling 2024 test set to {sample_test*100:.1f}%...")
        test_base = test_base.sample(False, sample_test, seed=seed)

    train_final = add_cyclical_features(create_threshold_labels(train_base))
    test_final = add_cyclical_features(create_threshold_labels(test_base))

    # 1. Historical frequency baseline from training data
    logger.info("Calculating historical frequency baseline rates from training data...")
    baseline_rates = (
        train_final.groupBy("threshold_mm")
        .agg(F.avg("label").alias("baseline_probability"))
    )

    # 2. Evaluate Base Model Discrimination
    logger.info(f"Loading trained base model from {model_dir / 'raincast_final_lr'}...")
    base_model = PipelineModel.load(str(model_dir / "raincast_final_lr"))

    test_predictions = base_model.transform(test_final)
    evaluator = BinaryClassificationEvaluator(labelCol="label", rawPredictionCol="rawPrediction")
    roc_auc = evaluator.evaluate(test_predictions, {evaluator.metricName: "areaUnderROC"})
    pr_auc = evaluator.evaluate(test_predictions, {evaluator.metricName: "areaUnderPR"})

    logger.info(f"=== 2024 Held-Out Test Set Performance ===")
    logger.info(f"Pooled ROC-AUC: {roc_auc:.4f}")
    logger.info(f"Pooled PR-AUC:  {pr_auc:.4f}")

    # 3. Probability Calibration Evaluation
    test_cal = (
        test_predictions
        .withColumn("p_raw", vector_to_array("probability")[1])
        .select("station_id", "time_bucket", "threshold_mm", "label", "p_raw")
    )

    p_clipped = F.greatest(F.lit(1e-6), F.least(F.col("p_raw"), F.lit(1.0 - 1e-6)))
    test_with_logit = test_cal.withColumn("logit_raw", F.log(p_clipped / (1.0 - p_clipped)))
    assembler = VectorAssembler(inputCols=["logit_raw"], outputCol="cal_features")

    calibrated_parts = []
    for t in KNOTS:
        cal_path = model_dir / f"calibrator_{int(t)}mm"
        if not cal_path.exists():
            logger.warning(f"Calibrator for {t} mm not found at {cal_path}. Skipping calibration for this knot.")
            continue
        calibrator = LogisticRegressionModel.load(str(cal_path))
        subset = test_with_logit.filter(F.col("threshold_mm") == t)
        prepared = assembler.transform(subset)
        scored = (
            calibrator.transform(prepared)
            .withColumn("p_calibrated", vector_to_array("probability")[1])
            .select("station_id", "time_bucket", "threshold_mm", "label", "p_raw", "p_calibrated")
        )
        calibrated_parts.append(scored)

    if calibrated_parts:
        calibrated_test = calibrated_parts[0]
        for part in calibrated_parts[1:]:
            calibrated_test = calibrated_test.unionByName(part)

        # Join baseline probabilities
        comparison_df = (
            calibrated_test.join(baseline_rates, "threshold_mm")
            .withColumn("raw_brier_sq", F.pow(F.col("p_raw") - F.col("label"), 2))
            .withColumn("cal_brier_sq", F.pow(F.col("p_calibrated") - F.col("label"), 2))
            .withColumn("base_brier_sq", F.pow(F.col("baseline_probability") - F.col("label"), 2))
        )

        results_summary = (
            comparison_df.groupBy("threshold_mm")
            .agg(
                F.count("*").alias("test_observations"),
                F.round(F.avg("label") * 100.0, 3).alias("actual_rate_pct"),
                F.round(F.avg("p_raw"), 5).alias("raw_mean_prob"),
                F.round(F.avg("p_calibrated"), 5).alias("calibrated_mean_prob"),
                F.round(F.avg("raw_brier_sq"), 5).alias("raw_brier"),
                F.round(F.avg("cal_brier_sq"), 5).alias("calibrated_brier"),
                F.round(F.avg("base_brier_sq"), 5).alias("baseline_brier")
            )
            .orderBy("threshold_mm")
        )

        logger.info("\n=== Detailed Brier Score Comparison vs Historical Baseline ===")
        results_summary.show(truncate=False)

        results_pd = results_summary.toPandas()
        out_csv = results_dir / "final_evaluation_results.csv"
        results_pd.to_csv(out_csv, index=False)
        logger.info(f"Evaluation summary saved to {out_csv}")

def main():
    parser = argparse.ArgumentParser(description="Evaluate Spark MLlib model on held-out test data.")
    parser.add_argument("--features-path", type=str, default="processed/features_all", help="Feature store parquet path")
    parser.add_argument("--model-dir", type=str, default="models", help="Directory containing trained models")
    parser.add_argument("--results-dir", type=str, default="results", help="Directory for output CSV results")
    parser.add_argument("--sample-test", type=float, default=0.10, help="Test set subsampling ratio")
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    model_dir = Path(args.model_dir)

    spark = get_spark_session(app_name="RainCastSG-Evaluate")
    try:
        evaluate_test_set(spark, model_dir, args.features_path, results_dir, sample_test=args.sample_test)
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
