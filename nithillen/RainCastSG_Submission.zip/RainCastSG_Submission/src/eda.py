"""
Exploratory Data Analysis (Task 1) for RainCastSG.

Performs Spark SQL aggregations across annual, seasonal, diurnal, intensity,
and spatial dimensions across 2017–2024 Singapore rainfall data.
"""
import argparse
from pathlib import Path
from pyspark.sql import functions as F

try:
    from .utils import get_spark_session, setup_logger
except ImportError:
    from utils import get_spark_session, setup_logger

logger = setup_logger("EDA")

def run_annual_analysis(spark, df, figures_dir: Path, results_dir: Path):
    """Computes annual station means, total observations, and wet percentage."""
    logger.info("Computing annual rainfall patterns...")
    annual_stats = df.groupBy("year", "station_id").agg(
        F.count("*").alias("observations"),
        F.sum("rainfall_mm").alias("annual_total_mm"),
        F.avg("rainfall_mm").alias("mean_5min_mm"),
        F.sum(F.when(F.col("rainfall_mm") > 0, 1).otherwise(0)).alias("wet_intervals")
    ).groupBy("year").agg(
        F.count("*").alias("stations"),
        F.round(F.avg("annual_total_mm"), 2).alias("avg_station_annual_mm"),
        F.round(F.avg("mean_5min_mm"), 4).alias("avg_5min_mm"),
        F.round(F.sum("wet_intervals") * 100.0 / F.sum("observations"), 2).alias("wet_interval_pct")
    ).orderBy("year")

    annual_stats.show(10, truncate=False)
    annual_pd = annual_stats.toPandas()
    annual_pd.to_csv(results_dir / "annual_statistics.csv", index=False)

    try:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 5))
        plt.bar(annual_pd["year"].astype(str), annual_pd["avg_station_annual_mm"], color="#2b5c8f", edgecolor="black")
        plt.xlabel("Year", fontsize=11)
        plt.ylabel("Mean Observed Annual Rainfall per Station (mm)", fontsize=11)
        plt.title("Singapore Annual Mean Rainfall per Station (2017–2024)", fontsize=13, fontweight="bold")
        plt.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        fig_path = figures_dir / "annual_rainfall.png"
        plt.savefig(fig_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved annual figure to {fig_path}")
    except Exception as e:
        logger.warning(f"Could not generate annual plot: {e}")

def run_monthly_analysis(spark, df, figures_dir: Path, results_dir: Path):
    """Computes monthly seasonality and year-by-month heatmap."""
    logger.info("Computing monthly seasonality and interannual variations...")
    monthly_stats = df.groupBy("year", "month", "station_id").agg(
        F.sum("rainfall_mm").alias("total_mm"),
        F.count("*").alias("observations")
    ).groupBy("year", "month").agg(
        F.count("*").alias("stations"),
        F.round(F.avg("total_mm"), 2).alias("avg_station_monthly_mm"),
        F.round(F.sum("total_mm") * 288.0 / F.sum("observations"), 2).alias("coverage_normalized_daily_mm")
    ).orderBy("year", "month")

    monthly_pd = monthly_stats.toPandas()
    monthly_pd.to_csv(results_dir / "monthly_statistics.csv", index=False)

    try:
        import matplotlib.pyplot as plt
        import pandas as pd
        import numpy as np

        seasonal = monthly_pd.groupby("month")["coverage_normalized_daily_mm"].mean()
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        plt.figure(figsize=(10, 5))
        plt.plot(month_names, seasonal.values, marker="o", linewidth=2.5, color="#1e3d59")
        plt.xlabel("Month", fontsize=11)
        plt.ylabel("Coverage-Normalized Daily Rainfall (mm)", fontsize=11)
        plt.title("Average Monthly Rainfall Seasonality in Singapore (2017–2024)", fontsize=13, fontweight="bold")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(figures_dir / "monthly_seasonality.png", dpi=300)
        plt.close()

        # Interannual heatmap
        heatmap_data = monthly_pd.pivot(index="year", columns="month", values="coverage_normalized_daily_mm").sort_index()
        fig, ax = plt.subplots(figsize=(12, 5))
        im = ax.imshow(heatmap_data.values, aspect="auto", cmap="YlGnBu")
        ax.set_xticks(range(12))
        ax.set_xticklabels(month_names)
        ax.set_yticks(range(len(heatmap_data.index)))
        ax.set_yticklabels(heatmap_data.index)
        for i in range(len(heatmap_data.index)):
            for j in range(12):
                val = heatmap_data.iloc[i, j]
                if pd.notna(val):
                    ax.text(j, i, f"{val:.1f}", ha="center", va="center", fontsize=8)
        plt.colorbar(im, ax=ax, label="Estimated daily rainfall (mm)")
        plt.title("Monthly Rainfall Patterns Across Years (2017–2024)", fontsize=13, fontweight="bold")
        plt.tight_layout()
        plt.savefig(figures_dir / "rainfall_heatmap.png", dpi=300)
        plt.close()
    except Exception as e:
        logger.warning(f"Could not generate monthly plots: {e}")

def run_diurnal_analysis(spark, df, figures_dir: Path, results_dir: Path):
    """Computes hourly wet interval frequencies and diurnal cycle."""
    logger.info("Computing diurnal rainfall cycle...")
    hourly_stats = df.groupBy("hour").agg(
        F.count("*").alias("observations"),
        F.round(F.avg("rainfall_mm"), 5).alias("mean_5min_rainfall"),
        F.round(100.0 * F.sum(F.when(F.col("rainfall_mm") > 0, 1).otherwise(0)) / F.count("*"), 2).alias("wet_interval_pct")
    ).orderBy("hour")

    hourly_stats.show(24, truncate=False)
    hourly_pd = hourly_stats.toPandas()
    hourly_pd.to_csv(results_dir / "diurnal_statistics.csv", index=False)

    try:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 5))
        plt.plot(hourly_pd["hour"], hourly_pd["wet_interval_pct"], marker="o", linewidth=2.5, color="#0f4c81")
        plt.xticks(range(0, 24, 2))
        plt.xlabel("Hour of Day (Singapore Time)", fontsize=11)
        plt.ylabel("Wet Observations (%)", fontsize=11)
        plt.title("Hourly Rainfall Occurrence in Singapore (2017–2024)", fontsize=13, fontweight="bold")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(figures_dir / "hourly_rainfall.png", dpi=300)
        plt.close()
    except Exception as e:
        logger.warning(f"Could not generate hourly plot: {e}")

def main():
    parser = argparse.ArgumentParser(description="Run Task 1 Exploratory Data Analysis.")
    parser.add_argument("--data-dir", type=str, default="processed", help="Directory with processed Parquet partitions")
    parser.add_argument("--figures-dir", type=str, default="figures", help="Output directory for generated figures")
    parser.add_argument("--results-dir", type=str, default="results", help="Output directory for CSV tables")
    args = parser.parse_args()

    figures_dir = Path(args.figures_dir)
    results_dir = Path(args.results_dir)
    figures_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    spark = get_spark_session(app_name="RainCastSG-EDA")
    try:
        data_path = Path(args.data_dir)
        year_paths = [str(p) for p in data_path.glob("rainfall_*")]
        if not year_paths:
            logger.error(f"No rainfall Parquet partitions found in {data_path}")
            return

        df = spark.read.parquet(*year_paths)
        df = (
            df
            .withColumn("year", F.year("timestamp_sgt"))
            .withColumn("month", F.month("timestamp_sgt"))
            .withColumn("hour", F.hour("timestamp_sgt"))
        )
        df.createOrReplaceTempView("rainfall")

        run_annual_analysis(spark, df, figures_dir, results_dir)
        run_monthly_analysis(spark, df, figures_dir, results_dir)
        run_diurnal_analysis(spark, df, figures_dir, results_dir)
        logger.info("EDA completed successfully!")
    finally:
        spark.stop()

if __name__ == "__main__":
    main()
